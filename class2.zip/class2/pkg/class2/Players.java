package class2;

public class Players {
	private String playername;
	private String playerposition;
	public Players(String playername, String playerposition) {
		super();
		this.playername = playername;
		this.playerposition = playerposition;
		System.out.println("Playername: "+playername+"  Playerposition: "+playerposition);
	}
}
